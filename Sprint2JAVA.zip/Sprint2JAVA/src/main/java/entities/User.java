
package entities;


import javax.persistence.CascadeType;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import java.util.Date;
import java.util.List;
import java.util.Set;

public class User {
    public List<EvenementUser> getEvenementUsers() {
        return evenementUsers;
    }

    public void setEvenementUsers(List<EvenementUser> evenementUsers) {
        this.evenementUsers = evenementUsers;
    }

    public User(List<EvenementUser> evenementUsers, int id, String name, String lastname, String password, String email, String roles, String image, int number, Date datenaissance, boolean is_verified) {
        this.evenementUsers = evenementUsers;
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.password = password;
        this.email = email;
        this.roles = roles;
        this.image = image;
        this.number = number;
        this.datenaissance = datenaissance;
        this.is_verified = is_verified;
    }

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<EvenementUser> evenementUsers;
    private int id;
    private String name;
    private String lastname;
    private String password;
    private String email;
    private String roles;
    private String image;
    private int number;
    private Date datenaissance;

    private boolean is_verified;

    public User() {

    }





    public User(int id, String name, String lastname, String password, String email, String roles, String image, int number, boolean is_verified, Date datenaissance) {
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.password = password;
        this.email = email;
        this.roles = roles;
        this.image = image;
        this.number = number;
        this.is_verified = is_verified;
        this.datenaissance= datenaissance;
    }



    public User(String name, String lastname, String password, String email, String roles, String image, int number, boolean is_verified, Date datenaissance) {

        this.name = name;
        this.lastname = lastname;
        this.password = password;
        this.email = email;
        this.roles = roles;
        this.image = image;
        this.number = number;
        this.is_verified = is_verified;
        this.datenaissance=datenaissance;
    }

    public User(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    public void setImage(String image) {
        this.image = image;
    }
    public void setNumber(int number) {
        this.number = number;
    }
    public void setIs_verified(boolean is_verified) {this.is_verified = is_verified;}
    public void setDatenaissance(Date datenaissance) {this.datenaissance = datenaissance;}


    @Override
    public String toString() {
        return "User{" + "id=" + id + ", name=" + name + ", lastname=" + lastname + ", password=" + password + ", email=" + email + ", roles=" + roles + ", image=" + image + ", Number="+number+" , is_verified="+is_verified+" , datenaissance"+datenaissance+'}';
    }


    public Date getDatenaissance() {return  datenaissance;}

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLastname() {
        return lastname;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getRoles() {
        return roles;
    }

    public String getImage() {
        return image;
    }
    public int getNumber() {
        return number;
    }

    public boolean getIs_verified() {return is_verified;}




}
