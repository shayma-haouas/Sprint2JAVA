package controllers;

import entities.Evenement;

public interface Mylistener {


    public void onClickListener(Evenement evenement);
}
